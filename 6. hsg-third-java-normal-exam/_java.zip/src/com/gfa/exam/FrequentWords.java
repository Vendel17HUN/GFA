package com.gfa.exam;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FrequentWords {
  public static void main(String[] args) throws IOException {
    getFrequentWords("resources/input.txt", 2);
  }

  private static void getFrequentWords(String filename, int frequency) throws IOException {
    if (!checkParams(filename, frequency)) {
      return;
    }

    Path path = Paths.get(filename);
    Path outputPath = Paths.get("output.txt");

    List<String> lines = Files.readAllLines(path);
    Map<String, Integer> counter = countWords(lines);

    String substring = getThisFrequentWords(counter, frequency);

    Files.write(outputPath, Collections.singleton(substring));
  }

  private static String getThisFrequentWords(Map<String, Integer> counter, int frequency) {
    StringBuilder builder = new StringBuilder();
    counter.entrySet().stream()
        .filter(entry -> entry.getValue() == frequency)
        .sorted(Map.Entry.comparingByKey())
        .forEach(entry -> builder.append(entry.getKey()).append(", "));
    return builder.substring(0, builder.length() - 2);
  }

  private static Map<String, Integer> countWords(List<String> lines) {
    Map<String, Integer> counter = new HashMap<>();
    for (String line : lines) {
      String[] words = line.split(" ");
      for (String word : words) {
        if (counter.containsKey(word)) {
          counter.put(word, counter.get(word) + 1);
        } else {
          counter.put(word, 1);
        }
      }
    }
    return counter;
  }

  private static boolean checkParams(String filename, int frequency) {
    if (filename == null || filename.equals("")) {
      throw new IllegalArgumentException("Illegal filename.");
    }

    if (frequency <= 0) {
      throw new IllegalArgumentException("Frequency can't be 0 or lower.");
    }

    if (!Files.exists(Paths.get(filename))) {
      System.out.println("File nem létezik: " + filename);
      return false;
    }
    return true;
  }
}
